from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/add", methods=["POST"])
def add():
    user = request.form.get("user")
    text = request.form.get("text")
    print(user)
    print(text)
    return redirect("/")


if __name__ == "__main__":
    app.run()
